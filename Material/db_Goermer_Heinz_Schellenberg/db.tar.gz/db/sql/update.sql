--Arbeitsdienste verändern
UPDATE arbeitsdienste SET faelligkeit = '2022-04-27' WHERE ad_id=3;
UPDATE arbeitsdienste SET faelligkeit = '2022-05-17' WHERE ad_id=7;
UPDATE arbeitsdienste SET faelligkeit = '2022-05-17' WHERE ad_id=9;
UPDATE arbeitsdienste SET faelligkeit = '2022-05-27' WHERE ad_id=11;
UPDATE arbeitsdienste SET faelligkeit = '2022-05-27' WHERE ad_id=15;
UPDATE arbeitsdienste SET faelligkeit = '2022-06-03' WHERE ad_id=17;
UPDATE arbeitsdienste SET faelligkeit = '2022-06-03' WHERE ad_id=28;

UPDATE arbeitsdienste SET faelligkeit = '2022-05-23' WHERE ad_id=2;
UPDATE arbeitsdienste SET faelligkeit = '2022-05-23' WHERE ad_id=4;
UPDATE arbeitsdienste SET faelligkeit = '2022-05-23' WHERE ad_id=14;