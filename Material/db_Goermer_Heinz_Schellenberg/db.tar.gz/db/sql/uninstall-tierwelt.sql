\i drop-tierwelt.sql
