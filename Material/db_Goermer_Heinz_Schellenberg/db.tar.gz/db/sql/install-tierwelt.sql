\i create-tierwelt.sql
\i grant-tierwelt.sql
\i insert-tierwelt_tierstrang.sql
\i insert-tierwelt_verbrauchsmittelstrang.sql
\i insert-tierwelt_dienstestrang.sql
