GRANT SELECT ON TABLE
  Habitattypen,
  Terrarien,
  Unterarten,
  Tiere,
  Verbrauchsmittel,
  Leuchtmittel,
  Deko,
  Bodenbelag,
  Pflanzen,
  Wasserbecken,
  Verbrauch,
  Arbeitsdiensttypen,
  Arbeitsdienste,
  Futter,
  Tierpflege,
  Terrariumpflege,
  Lagerpflege
TO lewein;

