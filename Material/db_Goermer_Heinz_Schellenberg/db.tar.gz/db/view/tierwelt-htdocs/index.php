<?php

  echo "
    <html>
      <head>
        <title>DB Tierwelt (INDEX)</title>
      </head>
      <body>
        <p>Überblick über die html | php | sql - Anbindung zur Datenbank Reptilien-Tierwelt</p>
        <div>
          <lable>Ansicht aller vorhandenen Tabellen</lable>
          <a href='showOverview.php'>hier</a>
        </div>
        <div>
          <lable>Aufgabenliste</lable>
          <a href='showTasks.php'>hier</a>
        </div>
        <div>
          <lable>Eingabeformular</lable>
          <a href='showFormular.php'>hier</a>
        </div>
      </body>
  </html>
  ";
?>